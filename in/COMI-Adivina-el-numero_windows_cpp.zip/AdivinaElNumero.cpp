#include "AdivinaElNumero.h"

// Main
//	long long pista(long long x)

void adivina(long long a, long long b) {
	// FIXME
}
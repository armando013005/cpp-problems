#include "jarras.h"

// Main
//	void verterAgua(int fuente, int destino)

void programa(int objetivo, int capacidadJarra1, int capacidadJarra2) {
	// FIXME
}
#include "PilaInteractivo.h"


void agrega(int n) {
	// FIXME
}

int saca() {
	// FIXME
	return 0;
}
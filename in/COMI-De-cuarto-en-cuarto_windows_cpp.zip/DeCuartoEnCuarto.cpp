#include "DeCuartoEnCuarto.h"

// Main
//	int siguienteCuarto(int n)
//	void move(int c)
//	void regresa()

void Player1(int x, int y) {
	// FIXME
}
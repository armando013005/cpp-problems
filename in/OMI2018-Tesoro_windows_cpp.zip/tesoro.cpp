#include "tesoro.h"

// Main
//	int Preguntar(int i, int j)
//	bool Cavar(int i, int j)

void BuscaTesoros(int n, int m, int k) {
	// FIXME
}
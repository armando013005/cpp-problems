#include "primo.h"

// Main
//	int primo(int posicion)

int busca(int n) {
	// FIXME
	return 0;
}